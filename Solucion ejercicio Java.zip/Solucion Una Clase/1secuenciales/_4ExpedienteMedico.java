/* 
* Una breve descripcion de lo que hace la clase
* @version 28 mayo 2021
* @author Denis Gonzalez
*/

//importar clases o paquetes
import java.util.Scanner;

// una class es un plano de construccion, es una declaracion de un programa
public class _4ExpedienteMedico { //inicio del bloque de la clase 
    
    public static void main (String args[]){ 
        //cuerpo del main
        // Paso 1 - definir variables y constantes 
        //tipo dato nombre de variable
        String nombre;
        int edad;
        char sexo;
        boolean esCasado;
        double peso;
        String expediente;

        // Paso 2 - obtenemos datos de entrada...
        Scanner leer = new Scanner(System.in); //requiere importar
        
        System.out.print("Digite su nombre: ");
        nombre = leer.next();

        System.out.print("Digite su edad: ");
        edad = leer.nextInt();

        System.out.print("Digite su sexo (M / F): ");
        sexo = leer.next().charAt(0);

        System.out.print("Es usted casado(a) (true/false)  ");
        esCasado = leer.nextBoolean();

        System.out.print("Digite su peso: ");
        peso = leer.nextDouble();


	    // Paso 3 - procesamiento de los datos  
        // Paso 4 - salida de informacion
        System.out.println("Su expediente es: \nNombre: " + nombre + "\nedad: " + edad + "\nSexo: " + sexo + "\nEs casado: " + esCasado + "\nPeso: " + peso);
    }
}
