/* 
* Una breve descripcion de lo que hace la clase
* @version 28 mayo 2021
* @author Denis Gonzalez
*/

//importar clases o paquetes
import java.util.Scanner;

// una class es un plano de construccion, es una declaracion de un programa
public class _2numeroContrario { //inicio del bloque de la clase 
    
    public static void main (String args[]){ 
        // Paso 1 - definir variables y constantes 
        //tipo dato nombre de variable
        int numeroIngresado;//declarar una variable
        int numContrario;

        	// Paso 2 - obtenemos datos de entrada... 
        Scanner leer = new Scanner(System.in); //requiere importar
        
        // COMO MOSTRAR DATOS DE SALIDA EN JAVA
        System.out.print("Por favor ingresar el numero a invertir el simbolo");
        numeroIngresado = leer.nextInt();

	    // Paso 3 - procesamiento de los datos
        numContrario = numeroIngresado * (-1); 
    
        // Paso 4 - salida de informacion
        System.out.printf("El numero contrario es: %d%n", numContrario);
    }
}
