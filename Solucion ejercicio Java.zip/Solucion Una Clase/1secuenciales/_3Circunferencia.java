/* 
* Una breve descripcion de lo que hace la clase
* @version 28 mayo 2021
* @author Denis Gonzalez
*/

//importar clases o paquetes
import java.util.Scanner;

// una class es un plano de construccion, es una declaracion de un programa
public class _3Circunferencia { //inicio del bloque de la clase 
    
    public static void main (String args[]){ 
        // Paso 1 - definir variables y constantes 
        //tipo dato nombre de variable
        final double CONST_PI = 3.14; //declarar una CONSTANTE
        double radio;
        double circunferencia;

        // Paso 2 - obtenemos datos de entrada...
        Scanner leer = new Scanner(System.in); //requiere importar
        
        // COMO MOSTRAR DATOS DE SALIDA EN JAVA
        System.out.print("Por favor digitar el radio ");
        radio = leer.nextDouble();

	    // Paso 3 - procesamiento de los datos
        circunferencia = radio * 2 * CONST_PI; 
    
        // Paso 4 - salida de informacion
        System.out.println("El valor de la circunferencia es: " + circunferencia);
    }
}
