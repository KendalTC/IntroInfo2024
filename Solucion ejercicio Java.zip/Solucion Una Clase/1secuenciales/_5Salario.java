/* 
* Una breve descripcion de lo que hace la clase
* @version 28 mayo 2021
* @author Denis Gonzalez
*/

//importar clases o paquetes
import java.util.Scanner;

// una class es un plano de construccion, es una declaracion de un programa
public class _5Salario { //inicio del bloque de la clase 
    
    public static void main (String args[]){ 
        // Paso 1 - definir variables y constantes 
        //tipo dato nombre de variable
        double salarioBase; //declarar una variable
        final int HORA_EXTRA = 3500;
        int cantHorasExtra;
        double salarioTotal;

       	// Paso 2 - obtenemos datos de entrada... 
        Scanner leer = new Scanner(System.in); //requiere importar
        
        System.out.print("Digite su salario base: ");
        salarioBase = leer.nextDouble();

        System.out.print("Digite las horas extras laboradas: ");
        cantHorasExtra = leer.nextInt();

	    // Paso 3 - procesamiento de los datos
        salarioTotal = salarioBase + (cantHorasExtra * HORA_EXTRA); 
    
        // Paso 4 - salida de informacion
        System.out.println("Su salario total es: " + salarioTotal);
    }
}
