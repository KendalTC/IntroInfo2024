/* 
* Una breve descripcion de lo que hace la clase
* @version 28 mayo 2021
* @author Denis Gonzalez
*/

//importar clases o paquetes
import java.util.Scanner;

// una class es un plano de construccion, es una declaracion de un programa
public class _1SumaEnteros { //inicio del bloque de la clase 
    //cuerpo de la clase
    
    public static void main (String args[]){ 
        //cuerpo del main
        // Paso 1 - definir variables y constantes 
        //tipo dato nombre de variable
        int primerOperando; //declarar una variable
        int segundoOperando;
        int resultadoSuma;

        	// Paso 2 - obtenemos datos de entrada... COMO OBTENER DATOS DE ENTRADA EN JAVA
        Scanner leer = new Scanner(System.in); //requiere importar
        
        // COMO MOSTRAR DATOS DE SALIDA EN JAVA
        System.out.print("Digite el primer operando: ");
        primerOperando = leer.nextInt();

        System.out.print("Digite el segundo operando: ");
        segundoOperando = leer.nextInt();

	    // Paso 3 - procesamiento de los datos
        resultadoSuma = primerOperando + segundoOperando; 
    
        // Paso 4 - salida de informacion
        System.out.printf("El resultado de la suma es %d%n", resultadoSuma);
    }
        

}// fin del bloque de la clase

// Comentarios explicativos:
// public : Puede compartir información con otras clases
// class : Una clase es el plano a partir del cual se crean los objetos individuales que componen un programa
// static: Solo va a existir un UNICO metodo o clase o variable en la memoria
// void:  traduccion vacio, no necesita retornar datos de SALIDA (o la salida es vacia)
// main: Nombre del UNICO y PRINCIPAL metodo de inicio del programa
// String: Un tipo de datos conocido como CADENA
// args[]: Una variable de tipo arreglo (Es tema de programación 1)
// { } : corchetes de inicio y fin de un bloque de codigo o sentencias de java
