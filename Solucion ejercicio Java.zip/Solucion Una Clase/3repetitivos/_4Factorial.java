/* 
* Completar breve descripcion del algoritmo
* @version 31 mayo 2021
* @author Denis Gonzalez
*/

//importar clases o paquetes
import java.util.Scanner;

// una clase es un plano de construccion, es una declaracion de un programa
public class _4Factorial { 

	public static void main (String args[]){ 
        // Paso 1 - definir variables y constantes
        int numCalFact;
        int factorial = 1;
        int contadorFact = 1;

        // Paso 2 - obtenemos datos de entrada
        Scanner leer = new Scanner (System.in);
        System.out.println("Por favor digite el valor a calcular: ");
        numCalFact = leer.nextInt();
        // Paso 3 - procesamiento de los datos
        // Paso 4 - salida de informacion
        do {
            contadorFact = contadorFact + 1;
		    factorial = factorial * contadorFact;
            System.out.println("El valor del contador: " + contadorFact + " El valor del factorial es; " +factorial);
        }while (contadorFact != numCalFact);
            System.out.println("El resultado del factorial es: " +factorial);

  	}//fin main        
}// fin del bloque de la clase
