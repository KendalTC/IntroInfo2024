/* 
* Completar breve descripcion del algoritmo
* @version 31 mayo 2021
* @author Denis Gonzalez
*/

//importar clases o paquetes
import java.util.Scanner;

// una clase es un plano de construccion, es una declaracion de un programa
public class _1TablaMultiplicar { 

	public static void main (String args[]){ 
        // Paso 1 - definir variables y constantes
        int operandoMulti;
        int resultadoMulti;

        // Paso 2 - obtenemos datos de entrada
        Scanner leer = new Scanner (System.in);
        System.out.println("Por favor digite el valor para calcular su tabla de multiplicar ");
        operandoMulti = leer.nextInt();
        // Paso 3 - procesamiento de los datos
        // Paso 4 - salida de informacion
        for(int i = 0; i <=10; i++){
            resultadoMulti = operandoMulti * i;
            System.out.println("La tabla del: " + operandoMulti + " por " + i + " es: " + resultadoMulti);
        }
  	}//fin main        
}// fin del bloque de la clase
