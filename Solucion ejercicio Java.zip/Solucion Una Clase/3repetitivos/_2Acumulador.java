/* 
* Completar breve descripcion del algoritmo
* @version 31 mayo 2021
* @author Denis Gonzalez
*/

//importar clases o paquetes
import java.util.Scanner;

// una clase es un plano de construccion, es una declaracion de un programa
public class _2Acumulador { 

	public static void main (String args[]){ 
        // Paso 1 - definir variables y constantes
        int numeroLeido = -1; // inicializar variables
        int totalAcumulado = 0; // inicializar variables

        // Paso 2 - obtenemos datos de entrada
        // Paso 3 - procesamiento de los datos
        while (numeroLeido != 0){
            Scanner leer = new Scanner (System.in);
            System.out.println("Por favor digite un número: ");
            numeroLeido = leer.nextInt();
            totalAcumulado = totalAcumulado + numeroLeido;

            System.out.println("El número leido es:" + numeroLeido + " - El acumulado es: " + totalAcumulado );
        }  
          // Paso 4 - salida de informacion
        System.out.println("El total acumulado es: " + totalAcumulado);     
    

        
      
  	}//fin main        
}// fin del bloque de la clase
