/* 
* Completar breve descripcion del algoritmo
* @version 31 mayo 2021
* @author Denis Gonzalez
*/

//importar clases o paquetes
import java.util.Scanner;

// una clase es un plano de construccion, es una declaracion de un programa
public class _5TorreAsteriscos { 

	public static void main (String args[]){ 
        // Paso 1 - definir variables y constantes
        int tam, filas;
        char simbolo;
        String piramide;
        filas = 0;
        piramide = "";

        // Paso 2 - obtenemos datos de entrada
        Scanner leer = new Scanner (System.in);
        System.out.println("Digite el tamaño de la piramide: ");
        tam = leer.nextInt();
        System.out.println("Digite el simbolo a utilizar: ");
        simbolo = leer.next().charAt(0);
        System.out.println("");
        // Paso 3 - procesamiento de los datos
        // Paso 4 - salida de informacion

        while (tam > filas){
 		    piramide = piramide + "" + simbolo; 
		    filas = filas + 1;  
            System.out.println("" + piramide);         
        }
  	}//fin main        
}// fin del bloque de la clase

