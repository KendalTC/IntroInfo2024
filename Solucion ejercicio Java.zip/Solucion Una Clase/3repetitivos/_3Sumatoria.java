/* 
* Completar breve descripcion del algoritmo
* @version 31 mayo 2021
* @author Denis Gonzalez
*/

//importar clases o paquetes
import java.util.Scanner;

// una clase es un plano de construccion, es una declaracion de un programa
public class _3Sumatoria { 

	public static void main (String args[]){ 
        // Paso 1 - definir variables y constantes
        int numCalSuma;
        int sumatoria = 0;
        int contadorSuma = 0;

        // Paso 2 - obtenemos datos de entrada
        Scanner leer = new Scanner (System.in);
        System.out.println("Por favor digite el valor a calcular: ");
        numCalSuma = leer.nextInt();
        
        // Paso 3 - procesamiento de los datos
        // Paso 4 - salida de informacion
        do{
            contadorSuma = contadorSuma + 1;
		    sumatoria = sumatoria + contadorSuma;
            System.out.println("El valor del contador: " + contadorSuma+ " El valor de la sumatoria es; " + sumatoria);
        }while(contadorSuma != numCalSuma);
            System.out.println("El resultado de la sumatoria es: " + sumatoria);

  	}//fin main        
}// fin del bloque de la clase
