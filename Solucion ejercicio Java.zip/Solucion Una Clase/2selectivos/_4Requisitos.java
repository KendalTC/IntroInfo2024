/* 
* Verifica si es mayor de edad
* @version 31 mayo 2021
* @author Denis Gonzalez
*/

//importar clases o paquetes
import java.util.Scanner;

// una clase es un plano de construccion, es una declaracion de un programa
public class _4Requisitos { 

	public static void main (String args[]){ 
        // Paso 1 - definir variables y constantes
        int memoria;
        int almacenamiento;
        int nucleos;

        final int RAM = 2048;
        final int DISCO = 500;
        final int CANT_NUCLEOS = 4;

        // Paso 2 - obtenemos datos de entrada
        Scanner leer = new Scanner (System.in);

        System.out.println("Digite la memoria: ");
        memoria = leer.nextInt();

        System.out.println("Digite la cant. Disco: ");
        almacenamiento = leer.nextInt();

        System.out.println("Digite los nucleos: ");
        nucleos = leer.nextInt();

        // Paso 3 - procesamiento de los datos
        if ( memoria >= RAM ){
            if ( almacenamiento > DISCO ){
                if ( nucleos == CANT_NUCLEOS ){
                    System.out.println("SI cumple");
                }else{
                    System.out.println("No cumple");
                }
            }else{
                System.out.println("No cumple");
            }            
        } else{
            System.out.println("No cumple");
        }//fin del if
  	}//fin main        
}// fin del bloque de la clase
