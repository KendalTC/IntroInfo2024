/* 
* Verifica si es mayor de edad
* @version 31 mayo 2021
* @author Denis Gonzalez
*/

//importar clases o paquetes
import java.util.Scanner;

// una clase es un plano de construccion, es una declaracion de un programa
public class _5PositivoNegativo { 

	public static void main (String args[]){ 
        // Paso 1 - definir variables y constantes
        int valorIngresado;

        // Paso 2 - obtenemos datos de entrada
        Scanner leer = new Scanner (System.in);

        System.out.println("Por favor Ingrese un número: ");
        valorIngresado = leer.nextInt();

        // Paso 3 - procesamiento de los datos
        if ( valorIngresado == 0 ){
            System.out.println("El valor ingresado es 0 ");
        } else{
            if ( valorIngresado < 0 ){
                System.out.println("El valor " + valorIngresado +" es negativo"); 
            }else{
                System.out.println("El valor " + valorIngresado +" es Positivo"); 
            }
        }//fin del if
  	}//fin main        
}// fin del bloque de la clase
