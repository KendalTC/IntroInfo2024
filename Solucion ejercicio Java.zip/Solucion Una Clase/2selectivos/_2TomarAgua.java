/* 
* Verifica si es mayor de edad
* @version 31 mayo 2021
* @author Denis Gonzalez
*/

//importar clases o paquetes
import java.util.Scanner;

// una clase es un plano de construccion, es una declaracion de un programa
public class _2TomarAgua { 

	public static void main (String args[]){ 
        // Paso 1 - definir variables y constantes
        String genero;

        // Paso 2 - obtenemos datos de entrada
        Scanner leer = new Scanner (System.in);
        System.out.println("Por favor ingrese su genero: (Hombre / Mujer)  ");
        genero = leer.next();

        // Paso 3 - procesamiento de los datos
        if ( genero.equals("Mujer") ){
            //verdadero // Paso 4 - salida de informacion
            System.out.println("Tomar 1,5 litros");        
        } else{
            //falso
                if ( genero.equals("Hombre") ){
                    System.out.println("Tomar 1 litros");
                }else{
                    System.out.println("Error solo se permite digitar: Hombre / Mujer");
                }
        }//fin del if
  	}//fin main        
}// fin del bloque de la clase
