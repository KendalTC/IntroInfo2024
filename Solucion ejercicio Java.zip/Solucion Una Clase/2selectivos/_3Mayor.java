/* 
* Verifica si es mayor de edad
* @version 31 mayo 2021
* @author Denis Gonzalez
*/

//importar clases o paquetes
import java.util.Scanner;

// una clase es un plano de construccion, es una declaracion de un programa
public class _3Mayor { 

	public static void main (String args[]){ 
        // Paso 1 - definir variables y constantes
        int numero1;
        int numero2;

        // Paso 2 - obtenemos datos de entrada
        Scanner leer = new Scanner (System.in);

        System.out.println("Digite el numero 1:  ");
        numero1 = leer.nextInt();

        System.out.println("Digite el numero 2:  ");
        numero2 = leer.nextInt();
       
 // Paso 3 - procesamiento de los datos
        if (numero1 > numero2){
            //verdadero
            System.out.println("El mayor es: " + numero1); 
        } else{
            //falso
                if (numero1 == numero2){
                    System.out.println("Los números son iguales: " + numero1);
                }else{
                    System.out.println("El mayor es: " + numero2);
                }
        }//fin del if
  	}//fin main        
}// fin del bloque de la clase
