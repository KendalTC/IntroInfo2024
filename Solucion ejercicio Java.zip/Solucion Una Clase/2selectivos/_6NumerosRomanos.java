/* 
* Convierte numeros enteros a romanos
* @version 31 mayo 2021
* @author Denis Gonzalez
*/

//importar clases o paquetes
import java.util.Scanner;

// una clase es un plano de construccion, es una declaracion de un programa
public class _6NumerosRomanos { 

	public static void main (String args[]){ 
        int numeroDecimal;
        String numRomano = "";//declarando e inicializando 

        Scanner leer = new Scanner(System.in);
        System.out.println("Por favor digite un número entre 1 y 5");
        numeroDecimal = leer.nextInt();

        switch (numeroDecimal){
            case 1:
                numRomano = "I";
                break;
            case 2:
                numRomano = "II";
                break;
            case 3:
                numRomano = "III";
                break;
            case 4:
                numRomano = "IV";
                break;
            case 5:
                numRomano = "V";
                break;
            default:
                System.out.println("Error - Solo se permiten valores entre 1 y 5");
            
        }        
          System.out.println("El resultado de convertir el número " + numeroDecimal + " a numero Romano es: " + numRomano);  
    }
}// fin del bloque de la clase
