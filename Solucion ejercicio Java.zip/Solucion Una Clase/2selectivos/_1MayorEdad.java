/* 
* Verifica si es mayor de edad
* @version 31 mayo 2021
* @author Denis Gonzalez
*/

//importar clases o paquetes
import java.util.Scanner;

// una clase es un plano de construccion, es una declaracion de un programa
public class _1MayorEdad { 

	public static void main (String args[]){ 
        // Paso 1 - definir variables y constantes
        int edad;
        final int MAYOR_EDAD = 18; // constantes

        // Paso 2 - obtenemos datos de entrada
        Scanner leer = new Scanner (System.in);
        System.out.println("Por favor digite su edad: ");
        edad = leer.nextInt();
        // Paso 3 - procesamiento de los datos
        if (edad >= MAYOR_EDAD){
            //verdadero
            System.out.println("SÍ es mayor de edad"); // Paso 4 - salida de informacion
        } else{
            //falso
            System.out.println("No es mayor de edad");
        }//fin del if
  	}//fin main        
}// fin del bloque de la clase
