/* 
* La clase permite leer dos numeros enteros y retornar su resultado
* @version 28 mayo 2021
* @author Denis Gonzalez
*/

public class PruebaSumaEnteros { 
    
    public static void main (String args[]){ 

        //declarar varias variables del mismo tipo
        int primerOperando, segundoOperando, resultadoSuma; 
        
        //declarar e inicializar variables en una instruccion
        Escribir escribir = new Escribir();
        Leer leer = new Leer(); 
           
        escribir.mensaje("Digite el primer operando: ");
        primerOperando = leer.siguienteEntero();
        
        escribir.mensaje("Digite el segundo operando: ");
        segundoOperando = leer.siguienteEntero();

        resultadoSuma = primerOperando + segundoOperando; 
    
	    escribir.mensaje("El resultado de la suma es " + resultadoSuma);
    }
}
