/* 
* La Clase es un objeto que permite escribir datos de salida en la terminal 
* mediante el objeto System del JDK de java
* @version 28 mayo 2021
* @author Denis Gonzalez
*/

public class Escribir {
	
	public Escribir(){
	
	}
	
	 // @param msj recibe un parametro de tipo String como mensaje
	public void mensaje (String msj){
		System.out.println(msj);
	}
} 

