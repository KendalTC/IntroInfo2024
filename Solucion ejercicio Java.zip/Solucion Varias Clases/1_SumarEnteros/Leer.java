/* 
* La Clase es un objeto que permite leer datos de entrada 
* mediante el objeto Scanner del JDK de java
* @version 28 mayo 2021
* @author Denis Gonzalez
*/

import java.util.Scanner;

public class Leer {
	
	public Scanner leer; // variable (Atributo del objeto)
	
	public Leer(){ // metodo que construye al objeto
		this.leer = new Scanner (System.in);
	}
	
	// @return el primer valor digitado como un valor entero
	public int siguienteEntero (){ // metodo
		return leer.nextInt();
	}

	// @return el primer valor digitado como un valor double, real o con decimales
	public double siguienteDouble (){ // metodo
		return leer.nextDouble();
	}

	// @return el primer valor digitado como un valor String o cadena
	public String siguienteString (){ // metodo
		return leer.next();
	}


} 

