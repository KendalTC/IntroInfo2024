package Vista.Scanner;

/*
 * @author Kendal Trejos Cubero 
 * @version 30/5/24
 */

public class Escritor {
	public Escritor() {

	}

	public void escribir(String mensaje) {
		System.out.println(mensaje);
	}

}
