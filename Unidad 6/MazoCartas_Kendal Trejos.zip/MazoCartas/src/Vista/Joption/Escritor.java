/*
 * @author Kendal Trejos Cubero 
 * @version 30/5/24
 */

package Vista.Joption;

import javax.swing.JOptionPane;

public class Escritor {
	public Escritor() {

	}

	public void escribir(String mensaje) {
		JOptionPane.showMessageDialog(null, mensaje);
	}
}
