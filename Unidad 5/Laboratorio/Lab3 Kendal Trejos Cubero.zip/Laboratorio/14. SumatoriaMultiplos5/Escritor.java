public class Escritor {
    public Escritor () {

    }
    public void escribir (String mensaje) {
        System.out.println(mensaje);
    }

}
