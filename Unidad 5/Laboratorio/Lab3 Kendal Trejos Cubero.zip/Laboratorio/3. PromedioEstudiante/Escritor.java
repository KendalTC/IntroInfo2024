/*
 * @version 7/5/24
 * @author Kendal Trejos Cubero
 */

import javax.swing.JOptionPane;

public class Escritor {
    public Escritor() {

    }
    public void escribir (String mensaje){
        JOptionPane.showMessageDialog(null, mensaje);
    }
}
