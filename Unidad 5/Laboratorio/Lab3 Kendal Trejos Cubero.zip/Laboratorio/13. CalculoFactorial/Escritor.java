/*
 * @author Kendal Trejos Cubero 
 * @version 8/5/24
 */
import javax.swing.JOptionPane;
public class Escritor {
    public Escritor () {

    }
    public void escribir (String mensaje) {
        JOptionPane.showMessageDialog(null,mensaje);
    }
}
